/*
 * adc_config.h
 *
 * Created: 16/05/2025 03:25:49 p. m.
 *  Author: Admin
 */ 


#ifndef ADC_CONFIG_H_
#define ADC_CONFIG_H_

void configurar_ADC(void);



#endif /* ADC_CONFIG_H_ */