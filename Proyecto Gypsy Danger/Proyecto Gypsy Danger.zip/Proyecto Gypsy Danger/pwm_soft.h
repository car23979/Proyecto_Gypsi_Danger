/*
 * pwm_soft.h
 *
 * Created: 16/05/2025 03:25:03 p. m.
 *  Author: Admin
 */ 


#ifndef PWM_SOFT_H_
#define PWM_SOFT_H_

void configurar_pwm_software(void);
void actualizar_PB3(uint16_t us);
void actualizar_PB4(uint16_t us);
void actualizar_PB5(uint16_t us);



#endif /* PWM_SOFT_H_ */